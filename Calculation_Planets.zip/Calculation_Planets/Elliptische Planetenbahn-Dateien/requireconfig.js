var require = {

    shim: {
        'jquery': {
            exports: '$'
        },
        'flot': {
            deps: ['jquery'],
            exports: '$.plot'
        },
        'flot.time': {
            deps: ['flot']
        }
    },

    paths: {
        jquery: "../../../lib/jquery-1.7.2.min",
        raphael: "../../../lib/raphael-min",
        flot: "../../../lib/flot/jquery.flot.min",
        "flot.time": "../../../lib/flot/jquery.flot.time.min",

        orion: '../../../lib/orionedit/web/orion',
        examples: '../../../lib/orionedit/web/examples',
        text: '../../../lib/orionedit/web/requirejs/text',
        i18n: '../../../lib/orionedit/web/requirejs/i18n',
        domReady: '../../../lib/orionedit/web/requirejs/domReady'

    }

};